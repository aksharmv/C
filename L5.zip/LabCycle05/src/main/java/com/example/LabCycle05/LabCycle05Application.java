package com.example.LabCycle05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabCycle05Application {

	public static void main(String[] args) {
		SpringApplication.run(LabCycle05Application.class, args);
	}

}
